// Mobile Navigation
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    }));
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Contact Form WhatsApp Integration
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const data = {};
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        // Create WhatsApp message
        let message = `🌟 *New Trial Class Request* 🌟\n\n`;
        message += `👤 *Student Name:* ${data.studentName}\n`;
        if (data.parentName) {
            message += `👨‍👩‍👧‍👦 *Parent/Guardian:* ${data.parentName}\n`;
        }
        message += `📧 *Email:* ${data.email}\n`;
        message += `📱 *WhatsApp:* ${data.phone}\n`;
        if (data.age) {
            message += `🎂 *Age:* ${data.age}\n`;
        }
        message += `📚 *Course:* ${data.course}\n`;
        if (data.experience) {
            message += `📖 *Experience:* ${data.experience}\n`;
        }
        if (data.timezone) {
            message += `🌍 *Timezone:* ${data.timezone}\n`;
        }
        if (data.preferredTime) {
            message += `⏰ *Preferred Time:* ${data.preferredTime}\n`;
        }
        if (data.message) {
            message += `💬 *Message:* ${data.message}\n`;
        }
        message += `\n✨ *From:* Mushaf Al Noor Academy Website`;
        
        // Encode message for WhatsApp URL
        const encodedMessage = encodeURIComponent(message);
        const whatsappURL = `https://wa.me/923709076083?text=${encodedMessage}`;
        
        // Show success message
        showFormMessage('Thank you! Redirecting to WhatsApp...', 'success');
        
        // Redirect to WhatsApp after a short delay
        setTimeout(() => {
            window.open(whatsappURL, '_blank');
            contactForm.reset();
        }, 1500);
    });
}

// Function to show form messages
function showFormMessage(message, type) {
    // Remove existing messages
    const existingMessages = document.querySelectorAll('.form-success, .form-error');
    existingMessages.forEach(msg => msg.remove());
    
    // Create new message
    const messageDiv = document.createElement('div');
    messageDiv.className = type === 'success' ? 'form-success' : 'form-error';
    messageDiv.textContent = message;
    
    // Insert message before the form
    contactForm.parentNode.insertBefore(messageDiv, contactForm);
    
    // Remove message after 5 seconds
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

// Chatbot functionality
const chatbotToggle = document.getElementById('chatbotToggle');
const chatbotContainer = document.getElementById('chatbotContainer');
const chatbotClose = document.getElementById('chatbotClose');
const chatbotMessages = document.getElementById('chatbotMessages');
const chatbotInput = document.getElementById('chatbotInput');
const chatbotSend = document.getElementById('chatbotSend');

// Chatbot responses
const chatbotResponses = {
    greeting: "Assalamu Alaikum! Welcome to Mushaf Al Noor Academy. How can I help you today?",
    courses: "We offer 4 main courses:\n\n📚 Noorani Qaida (Beginner)\n📖 Quran Reading with Tajweed\n🎯 Quran Memorization (Hifz)\n🔤 Arabic Language\n\nWhich course interests you?",
    fees: "Our course fees are very affordable:\n\n💰 Individual classes: $8-12 per hour\n👥 Group classes: $5-8 per hour\n📅 Monthly packages available\n🆓 First trial class is FREE!\n\nContact us for detailed pricing!",
    teachers: "Our teachers are:\n\n✅ Qualified with Ijazah certification\n✅ Experienced in online teaching\n✅ Native Arabic speakers\n✅ Patient with all age groups\n✅ Available 24/7 worldwide\n\nWould you like to meet them?",
    timing: "We offer flexible timing:\n\n🌍 Available 24/7 worldwide\n⏰ Choose your preferred time\n📅 7 days a week\n🔄 Reschedule if needed\n\nWhat timezone are you in?",
    trial: "Book your FREE trial class:\n\n🎯 30-minute session\n👨‍🏫 Meet your teacher\n📚 Assess your level\n💯 No commitment required\n\nReady to start? Fill our contact form!",
    contact: "Contact us anytime:\n\n📧 mushafalnur114@gmail.com\n📱 WhatsApp: +92 370 907 6083\n🌐 Available 24/7\n\nOr use our contact form below!",
    age: "We teach all ages:\n\n👶 Kids (4+ years)\n👦 Teenagers\n👨 Adults\n👴 Seniors\n\nEveryone is welcome to learn the Quran!",
    technology: "Easy to join classes:\n\n💻 Any device (computer, tablet, phone)\n🌐 Stable internet connection\n🎧 Headphones recommended\n📱 WhatsApp or Zoom\n\nNo technical skills needed!",
    default: "I understand you're asking about our Quran academy. Here are some topics I can help with:\n\n📚 Courses\n💰 Fees\n👨‍🏫 Teachers\n⏰ Timing\n🆓 Free Trial\n📞 Contact\n👶 Age Groups\n💻 Technology\n\nWhat would you like to know?"
};

// Initialize chatbot
if (chatbotToggle && chatbotContainer) {
    // Add initial greeting
    addBotMessage(chatbotResponses.greeting);
    
    chatbotToggle.addEventListener('click', () => {
        chatbotContainer.classList.toggle('active');
    });
    
    if (chatbotClose) {
        chatbotClose.addEventListener('click', () => {
            chatbotContainer.classList.remove('active');
        });
    }
    
    if (chatbotSend && chatbotInput) {
        chatbotSend.addEventListener('click', sendMessage);
        chatbotInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
}

function sendMessage() {
    const message = chatbotInput.value.trim();
    if (message) {
        addUserMessage(message);
        chatbotInput.value = '';
        
        // Process message and get response
        setTimeout(() => {
            const response = processMessage(message);
            addBotMessage(response);
        }, 1000);
    }
}

function addUserMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'user-message';
    messageDiv.innerHTML = `<p>${message}</p>`;
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

function addBotMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'bot-message';
    messageDiv.innerHTML = `<p>${message.replace(/\n/g, '<br>')}</p>`;
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

function processMessage(message) {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('course') || lowerMessage.includes('class') || lowerMessage.includes('subject')) {
        return chatbotResponses.courses;
    } else if (lowerMessage.includes('fee') || lowerMessage.includes('price') || lowerMessage.includes('cost') || lowerMessage.includes('money')) {
        return chatbotResponses.fees;
    } else if (lowerMessage.includes('teacher') || lowerMessage.includes('instructor') || lowerMessage.includes('tutor')) {
        return chatbotResponses.teachers;
    } else if (lowerMessage.includes('time') || lowerMessage.includes('schedule') || lowerMessage.includes('timing') || lowerMessage.includes('when')) {
        return chatbotResponses.timing;
    } else if (lowerMessage.includes('trial') || lowerMessage.includes('free') || lowerMessage.includes('demo')) {
        return chatbotResponses.trial;
    } else if (lowerMessage.includes('contact') || lowerMessage.includes('phone') || lowerMessage.includes('email') || lowerMessage.includes('whatsapp')) {
        return chatbotResponses.contact;
    } else if (lowerMessage.includes('age') || lowerMessage.includes('old') || lowerMessage.includes('kid') || lowerMessage.includes('child')) {
        return chatbotResponses.age;
    } else if (lowerMessage.includes('technology') || lowerMessage.includes('computer') || lowerMessage.includes('device') || lowerMessage.includes('internet')) {
        return chatbotResponses.technology;
    } else if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('assalam') || lowerMessage.includes('salam')) {
        return chatbotResponses.greeting;
    } else {
        return chatbotResponses.default;
    }
}

// Scroll to top functionality
const scrollToTopBtn = document.getElementById('scrollToTop');

if (scrollToTopBtn) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollToTopBtn.classList.add('visible');
        } else {
            scrollToTopBtn.classList.remove('visible');
        }
    });
    
    scrollToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Animation on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.course-card, .teacher-card, .testimonial-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});

